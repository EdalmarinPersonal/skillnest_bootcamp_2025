function miEdad() {

    console.log("Tengo: " + 25 + " años");

}
//Predicción 1. imprime en la consola: Tengo 25 años

function miEdad(edad) {

    console.log("Tengo: " + edad + " años");

}
//Predicción 2. imprime en la consola: Tengo 25 años

function restar(primerNumero, segundoNumero) {

    console.log("¡Restemos los números!");

    console.log("primerNumero es:" + primerNumero);

    console.log("segundoNumero es:" + segundoNumero);

    var resultado = primerNumero - segundoNumero;

    console.log(resultado);

}

//Prediccion 3:
//¡Restemos los números!
//primerNumero es:50
//segundoNumero es:27
//23